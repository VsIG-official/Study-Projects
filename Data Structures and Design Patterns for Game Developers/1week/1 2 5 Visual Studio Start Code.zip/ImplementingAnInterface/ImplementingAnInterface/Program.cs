﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplementingAnInterface
{
    /// <summary>
    /// Implementing an Interface lecture code
    /// </summary>
    class Program
    {
        /// <summary>
        /// Demonstrates implementing an interface
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            // create array of rectangles

            // add rectangles to array

            // print rectangles in array

            Console.WriteLine();
        }
    }
}
