﻿using UnityEngine.Events;

public class MessageEvent : UnityEvent
{
}
