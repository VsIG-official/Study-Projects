﻿using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// An event invoker
/// </summary>
public class Invoker : MonoBehaviour
{
	Listener listner = new Listener();
	Timer MessageTimer;
	Timer CountMessageTimer;
	int count;
	MessageEvent messageEvent = new MessageEvent();
	private CountMessageEvent countMessageEvent = new CountMessageEvent();

	public void Awake()
	{
	}

	public void Start()
	{
		MessageTimer = gameObject.AddComponent<Timer>();
		MessageTimer.Duration = 1;
		MessageTimer.Run();
		EventManager.AddNoArgumentInvoker(this);
		EventManager.AddIntArgumentInvoker(this);
	}

	void Update()
	{
		if (MessageTimer.Finished)
		{
			messageEvent.Invoke();
			MessageTimer.Run();
		}
	}

	public void AddNoArgumentListener(UnityAction listener)

	{
		messageEvent = new MessageEvent();
		messageEvent.AddListener(listener);
	}

	public void AddOneArgumentListener(UnityAction<int> listener)
	{
		countMessageEvent.AddListener(listener);
	}

	public void RemoveNoArgumentListener(UnityAction listener)
	{
		messageEvent.RemoveListener(listener);
	}

	public void RemoveOneArgumentListener(UnityAction<int> listener)
	{
		countMessageEvent.RemoveListener(listener);
	}

	public void InvokeNoArgumentEvent()
	{
	}

	public void InvokeOneArgumentEvent(int argument)
	{
		listner.HandleCountMessageEvent(argument);
		countMessageEvent.Invoke(argument);
	}
}