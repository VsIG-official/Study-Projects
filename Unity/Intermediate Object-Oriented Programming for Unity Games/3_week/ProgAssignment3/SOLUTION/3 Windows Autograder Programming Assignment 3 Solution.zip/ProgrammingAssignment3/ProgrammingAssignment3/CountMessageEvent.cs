﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// A one argument event
/// </summary>
public class CountMessageEvent : UnityEvent<int>
{
}
