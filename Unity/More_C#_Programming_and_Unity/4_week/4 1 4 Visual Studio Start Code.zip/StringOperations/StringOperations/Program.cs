﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOperations
{
    /// <summary>
    /// String Operations lecture code
    /// </summary>
    class Program
    {
        /// <summary>
        /// Demonstrates IndexOf and Substring methods
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            // read in csv string


            // find comma location


            // extract name and percent


            // print name and percent


            Console.WriteLine();
        }
    }
}
